package gg.archipelago.client.Print;

public class APPrintPart {
    public APPrintType type = APPrintType.TEXT;
    public String text = "";
}
