package gg.archipelago.client.network;

public enum ConnectionResult {
    Success,InvalidSlot, SlotAlreadyTaken, IncompatibleVersion, InvalidPassword
}
