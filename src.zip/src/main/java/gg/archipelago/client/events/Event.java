package gg.archipelago.client.events;

public interface Event {
}
